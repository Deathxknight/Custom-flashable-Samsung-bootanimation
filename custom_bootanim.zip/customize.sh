#!/system/bin/sh
# Set permissions
chmod 644 $MODPATH/system/media/bootsamsung.qmg
chmod 644 $MODPATH/system/media/bootsamsungloop.qmg
chmod 644 $MODPATH/system/media/shutdown.qmg
